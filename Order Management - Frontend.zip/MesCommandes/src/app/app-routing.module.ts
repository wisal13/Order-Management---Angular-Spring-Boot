import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommandesComponent } from './commandes/commandes.component';
import { AddCommandeComponent } from './add-commande/add-commande.component';
import { UpdateCommandeComponent } from './update-commande/update-commande.component';
import { LoginComponent } from './login/login.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { CommandeGuard } from './commande.guard';
import { ClientsComponent } from './clients/clients.component';
import { AddClientComponent } from './add-client/add-client.component';
import { RechercheParClientComponent } from './recherche-par-client/recherche-par-client.component';
import { RechercheParEtatComponent } from './recherche-par-etat/recherche-par-etat.component';


const routes: Routes = [
  {path: "commandes", component : CommandesComponent},
  {path: "clients", component : ClientsComponent},
  {path: "add-commande", component : AddCommandeComponent, canActivate:[CommandeGuard]},
  {path: "add-client", component : AddClientComponent},
  { path: "updateCommande/:id", component: UpdateCommandeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'app-forbidden', component: ForbiddenComponent},
  {path: "rechercheParClient", component : RechercheParClientComponent},
  {path: "rechercheParEtat", component : RechercheParEtatComponent},
  { path: "", redirectTo: "commandes", pathMatch: "full" } 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
