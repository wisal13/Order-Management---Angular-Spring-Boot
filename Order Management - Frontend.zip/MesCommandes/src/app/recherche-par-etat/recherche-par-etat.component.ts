import { Commande } from './../model/commande';
import { Component, OnInit } from '@angular/core';
import { CommandeService } from '../services/commande.service';

@Component({
  selector: 'app-recherche-par-etat',
  templateUrl: './recherche-par-etat.component.html',
  styles: [
  ]
})
export class RechercheParEtatComponent implements OnInit {

  commandes : Commande[]; //un tableau 
  idCommande : number;

  constructor(private commandeService: CommandeService) { }

  ngOnInit(): void {
  // this.commandes = this.commandeService.listeCommande();
 /* this.commandeService.listeCommande()._subscribe(
    (commandes: Commande[]) => { this.commandes = this.commandes; } 
  ); */
  }

  onChange() {
     this.commandes =  this.commandeService.rechercherParEtat(this.idCommande);
     console.log(this.commandes);
     
     }

}
