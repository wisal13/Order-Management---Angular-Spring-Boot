import { Client } from './../model/client';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClientService {


  clients: Client[]=[]; //un tableau de clients

  constructor(private http: HttpClient) {
    /*
    this.clients = [
      {idCommande : 1, prixTotal : 500.2, etat : "Livré", dateCreation : new Date("10/24/2021")},
      {idCommande : 2, prixTotal : 85.7, etat : "Annulé", dateCreation : new Date("10/24/2021")},
      {idCommande : 3, prixTotal : 50.4, etat : "Expedié", dateCreation : new Date("10/24/2021")}

    ];  */
  }

  ajouterClient(client: Client) {
    this.clients.push(client);
  }

  consulterClient(id: number): Client {
    return this.clients.find(p => p.idCl == id);
    //return this.client;
  }

  trierClients() {
    this.clients = this.clients.sort((n1, n2) => {
      if (n1.idCl > n2.idCl) {
        return 1;
      }
      if (n1.idCl < n2.idCl) {
        return -1;
      }
      return 0;
    });
  }

}
