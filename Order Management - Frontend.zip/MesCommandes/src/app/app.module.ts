import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CommandesComponent } from './commandes/commandes.component';
import { AddCommandeComponent } from './add-commande/add-commande.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UpdateCommandeComponent } from './update-commande/update-commande.component';
import { LoginComponent } from './login/login.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { ClientsComponent } from './clients/clients.component';
import { AddClientComponent } from './add-client/add-client.component';
import { RechercheParClientComponent } from './recherche-par-client/recherche-par-client.component';
import { RechercheParEtatComponent } from './recherche-par-etat/recherche-par-etat.component';

@NgModule({
  declarations: [
    AppComponent,
    CommandesComponent,
    AddCommandeComponent,
    UpdateCommandeComponent,
    LoginComponent,
    ForbiddenComponent,
    ClientsComponent,
    RechercheParClientComponent,
    RechercheParEtatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
