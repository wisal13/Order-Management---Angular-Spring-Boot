import { Component, OnInit } from '@angular/core';
import { Commande } from '../model/commande';
import { CommandeService } from '../services/commande.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Client } from '../model/client';

@Component({
  selector: 'app-add-commande',
  templateUrl: './add-commande.component.html'
})
export class AddCommandeComponent implements OnInit {

  newCommande = new Commande();
  newClient =new Client();
  clients : Client[];
  newIdCl : number;

  message :string;

  constructor(private commandeService: CommandeService,  private router :Router) { 
    
  }

  ngOnInit(): void {
    this.clients = this.commandeService.listeClients();
  }

 /* addCommande(){
    //console.log(this.newCommande);
    this.commandeService.ajouterCommande(this.newCommande);
    this.message = "Commande " + this.newCommande.idCommande + " ajouté avec succès !";

    } */

    addCommande(){
      this.newClient = this.commandeService.consulterClient(this.newIdCl);
      this.newCommande.client = this.newClient;
      this.commandeService.ajouterCommande(this.newCommande).subscribe(comnd => {
      console.log(comnd);
      });
      this.router.navigate(['commandes']).then(() => {
        window.location.reload();
      }
      );

      }
      


}
