import { Client } from './../model/client';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Commande } from '../model/commande';
import { CommandeService } from '../services/commande.service';

@Component({
  selector: 'app-update-commande',
  templateUrl: './update-commande.component.html',
  styles: []
})
export class UpdateCommandeComponent implements OnInit {

  currentCommande = new Commande();
  clients : Client[];
  updatedClient : Client;
  idCl : Client["idCl"];

  constructor(private activatedRoute: ActivatedRoute,
                private router :Router,
                private commandeService: CommandeService) { }

  ngOnInit(): void {
  //  console.log(this.activatedRoute.snapshot.params.id);
     /* this.currentCommande = this.commandeService.consulterCommande(this.activatedRoute.snapshot.params.id);
      console.log(this.currentCommande); */

      this.clients = this.commandeService.listeClients();

      this.commandeService.consulterCommande(this.activatedRoute.snapshot.params.id).
      subscribe( comnd =>{ this.currentCommande = comnd; } ) ;

}

    /*
    updateCommande() {
      //console.log(this.currentCommande);
      this.commandeService.updateCommande(this.currentCommande);
      this.router.navigate(["commandes"]);
    } */

    updateCommande() {
      this.updatedClient = this.commandeService.consulterClient(this.currentCommande.client?.idCl);
      this.currentCommande.client = this.updatedClient;  
      this.commandeService.updateCommande(this.currentCommande).subscribe(comnd => {
      this.router.navigate(['commandes']);
      },(error) => { alert("Problème lors de la modification !"); }
      );
      }
      

}
